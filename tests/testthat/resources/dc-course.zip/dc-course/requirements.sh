# Use this file to install Linux software packages into the course image.
# R packages should be installed from requirements.R
# There is a list of available Linux packages at
# https://packages.debian.org/testing/allpackages

# e.g., XML and Cairo graphics
# apt-get update && apt-get --yes --force-yes install libxml2-dev libcairo2-dev

# For dagitty
apt-get update && apt-get --yes --force-yes install librsvg2-dev libv8-dev
