library(remotes)

install_version("dplyr", "0.8.0")
install_version("tidyr", "0.8.3")
install_version("glue", "1.3.1")
install_version("purrr", "0.3.2")
install_version("stringr", "1.4.0")
